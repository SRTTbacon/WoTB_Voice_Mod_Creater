import os
import struct
import zlib
import sys
from _block import compress, decompress, LZ4BlockError

FOOTER_STRUCTURE = '4I4s'
FOOTER_SIZE = struct.calcsize(FOOTER_STRUCTURE)

inputFile = sys.argv[-2]
outputFile = sys.argv[-1]

with open(inputFile, 'rb') as f, open(outputFile, 'wb') as out:
        f.seek(-FOOTER_SIZE, os.SEEK_END)
        unpacked, packed, crc, ptype, marker = struct.unpack(FOOTER_STRUCTURE, f.read(FOOTER_SIZE))
        f.seek(0)
        result = decompress(f.read(packed), uncompressed_size=unpacked)
        out.write(result)
        out.close()
        f.close()